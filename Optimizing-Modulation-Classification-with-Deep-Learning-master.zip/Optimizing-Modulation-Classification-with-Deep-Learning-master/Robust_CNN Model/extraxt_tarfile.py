import tarfile
tar = tarfile.open("./RML2016.10a.tar.bz2", "r:bz2")  
tar.extractall()